<div class="department-menu_block">
                  <div class="department-menu d-flex justify-content-between align-items-center"><i class="fas fa-bars"></i>Categories<span><i class="arrow_carrot-down"></i></span></div>
                  <div class="department-dropdown-menu">
                    <ul>
                      <li><a href="sub-categories"> <i class="icon-1"></i>Fresh Meat</a></li>
                      <li><a href="sub-categories"> <i class="icon-2"></i>Vegetables</a></li>
                      <li><a href="sub-categories"> <i class="icon-3"></i>Fruit & Nut Gifts</a></li>
                      <li><a href="sub-categories"> <i class="icon-4"></i>Fresh Berries</a></li>
                      <li><a href="sub-categories"> <i class="icon-5"></i>Ocean Foods</a></li>
                      <li><a href="sub-categories"><i class="icon-6"></i>Butter & Eggs</a></li>
                      <li><a href="sub-categories"><i class="icon-7"></i>Fastfood</a></li>
                      <li><a href="sub-categories"> <i class="icon-8"></i>Fresh Onion</a></li>
                      <li><a href="sub-categories"> <i class="icon-9"></i>Papayaya & Crisps</a></li>
                      <li><a href="sub-categories"><i class="icon-10"></i>Oatmeal</a></li>
                      <li><a href="sub-categories"> <i class="icon_plus"></i>Others</a></li>
                    </ul>
                  </div>
                </div>