<div class="deal-of-week_v3">
        <div class="container">
          <div class="deal-of-week_block">
            <div class="row align-items-center justify-content-center">
              <div class="col-10 col-lg-6">
                <div class="dow-img"><img class="mymove" src="assets/images/homepage05/test2.jpeg" alt=""></div>
              </div>
              <div class="col-12 col-sm-11 col-lg-5">
                <div class="dow-info text-center text-lg-left">
                  <h2 class="title coffee-underline">Deal Of The Week</h2>
                  <h3 class="deal-price">₦19.00 <span>/ Package</span></h3>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisiing elit, sed do eiusmod tempor incididunt ut labore et </p>
                  <!-- <div class="d-flex justify-content-center justify-content-lg-start" id="event-countdown"></div> -->
                  <a class="normal-btn coffee" href="shop_grid+list_3col">Shop now		</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>