<div class="fab-wrapper">
            <input id="fabCheckbox" type="checkbox" class="fab-checkbox" />
            <label class="fabbutton" for="fabCheckbox">
                <span class="fab-dots fab-dots-1"></span>
                <span class="fab-dots fab-dots-2"></span>
                <span class="fab-dots fab-dots-3"></span>
            </label>
            <div class="fab-wheel">
                <a class="fab-action fab-action-1">
                    <i class="fab fa-facebook text-light"></i>
                </a>
                <a class="fab-action fab-action-2">
                    <i class="fab fa-whatsapp text-light"></i>
                </a>
                <a class="fab-action fab-action-3">
                    <i class="fas fa-comments text-light"></i>
                </a>
                <a class="fab-action fab-action-4">
                    <i class="fas fa-info text-light"></i>
                </a>
            </div>
        </div>